#NCL Data Wrangling and cleaning

#Importing NO2 data
ncl_no2= read.csv("C:/Users/Shubham/OneDrive/Documents/Disteration_R_code/Dissertation_UK_AirQuality/UK_AirQuality_Dissertation/Data prepared for Analysis/final_no2_ncl_data.csv")

#Remove the unwanted columns
colnames(ncl_no2)
ncl_no2= within(ncl_no2, rm(X))

summary(ncl_no2)



library(dplyr)

############NO2 Outlier detection
max(ncl_no2$Value)
min(ncl_no2$Value)


ncl_no2$Value <- as.numeric(ncl_no2$Value)

Hist= hist(ncl_no2$Value,
           main="Understanding the No2 data for Newcastle",
           xlab="Sensor readings",
           ylab="No2 Value",
           col="darkmagenta",
           freq=FALSE
)

boxplot(ncl_no2$Value,
        ylab = "No2")

#find Q1, Q3, and interquartile range for values in column Value
Q1 <- quantile(ncl_no2$Value, .25)
Q3 <- quantile(ncl_no2$Value, .75)
IQR <- IQR(ncl_no2$Value)

#only keep rows in dataframe that have values within 1.5*IQR of Q1 and Q3
no_outliers <- subset(ncl_no2, ncl_no2$Value> (Q1 - 1.5*IQR) & ncl_no2$Value< (Q3 + 1.5*IQR))

#Removing negative values
NCL_no2 <- no_outliers[no_outliers$Value >= 0, ]

#Understanding data after outlier are removed
Hist= hist(NCL_no2$Value,
           main="Understanding the No2 data for Newcastle",
           xlab="Sensor readings",
           ylab="No2 Value",
           col="darkmagenta",
           freq=FALSE
)


boxplot(NCL_no2$Value,
        ylab = "No2")

#It can be seen that there are still outlier which are to be removed
NCL_no2 <- NCL_no2[NCL_no2$Value <= 500,] 

boxplot(NCL_no2$Value,
        ylab = "No2")

write.csv(NCL_no2,"C:/Users/Shubham/OneDrive/Documents/Disteration_R_code/Dissertation_UK_AirQuality/UK_AirQuality_Dissertation/Data ready for forecasting/NCL_NO2_data_for_forecast.csv")


###########Importing PM10 data###########

ncl_pm10= read.csv("C:/Users/Shubham/OneDrive/Documents/Disteration_R_code/Dissertation_UK_AirQuality/UK_AirQuality_Dissertation/Data prepared for Analysis/final_pm10_ncl_data.csv")

#Remove the unwanted columns
colnames(ncl_pm10)
ncl_pm10= within(ncl_pm10, rm(X))

summary(ncl_pm10)

############PM10 Outlier detection
max(ncl_pm10$Value)
min(ncl_pm10$Value)


ncl_pm10$Value <- as.numeric(ncl_pm10$Value)



Hist= hist(ncl_pm10$Value,
           main="Understanding the PM10 data for Newcastle",
           xlab="Sensor readings",
           ylab="PM10 Value",
           col="darkmagenta",
           freq=FALSE
)

boxplot(ncl_pm10$Value,
        ylab = "Pm10")

#find Q1, Q3, and interquartile range for values in column Value
Q1 <- quantile(ncl_pm10$Value, .25)
Q3 <- quantile(ncl_pm10$Value, .75)
IQR <- IQR(ncl_pm10$Value)

#only keep rows in dataframe that have values within 1.5*IQR of Q1 and Q3
no_outliers <- subset(ncl_pm10, ncl_pm10$Value> (Q1 - 1.5*IQR) & ncl_pm10$Value< (Q3 + 1.5*IQR))

#Removing negative values
NCL_pm10 <- no_outliers[no_outliers$Value >= 0, ]

#Understanding data after outlier are removed
Hist= hist(NCL_pm10$Value,
           main="Understanding the Pm10 data for Newcastle",
           xlab="Sensor readings",
           ylab="Pm10 Value",
           col="darkmagenta",
           freq=FALSE
)


boxplot(NCL_pm10$Value,
        ylab = "Pm10")

#It can be seen that there are still outlier which are to be removed
NCL_pm10 <- NCL_pm10[NCL_pm10$Value <= 500,] 

boxplot(BHM_pm10$Value,
        ylab = "Pm10")

write.csv(NCL_pm10,"C:/Users/Shubham/OneDrive/Documents/Disteration_R_code/Dissertation_UK_AirQuality/UK_AirQuality_Dissertation/Data ready for forecasting/NCL_PM10_data_for_forecast.csv")

