#BHM Data Wrangling and cleaning

#Importing NO2 data
bhm_no2= read.csv("C:/Users/Shubham/OneDrive/Documents/Disteration_R_code/Dissertation_UK_AirQuality/UK_AirQuality_Dissertation/Data prepared for Analysis/final_no2_bhm_data.csv")

#Remove the unwanted columns
colnames(bhm_no2)
bhm_no2= within(bhm_no2, rm(X))

summary(bhm_no2)

library(dplyr)

############NO2 Outlier detection
max(bhm_no2$Value)
min(bhm_no2$Value)


bhm_no2$Value <- as.numeric(bhm_no2$Value)

Hist= hist(bhm_no2$Value,
           main="Understanding the No2 data for Birmingham",
           xlab="Sensor readings",
           ylab="No2 Value",
           col="darkmagenta",
           freq=FALSE
)

boxplot(bhm_no2$Value,
        ylab = "No2")

#find Q1, Q3, and interquartile range for values in column Value
Q1 <- quantile(bhm_no2$Value, .25)
Q3 <- quantile(bhm_no2$Value, .75)
IQR <- IQR(bhm_no2$Value)

#only keep rows in dataframe that have values within 1.5*IQR of Q1 and Q3
no_outliers <- subset(bhm_no2, bhm_no2$Value> (Q1 - 1.5*IQR) & bhm_no2$Value< (Q3 + 1.5*IQR))

#Removing negative values
BHM_no2 <- no_outliers[no_outliers$Value >= 0, ]

#Understanding data after outlier are removed
Hist= hist(BHM_no2$Value,
           main="Understanding the No2 data for Manchester",
           xlab="Sensor readings",
           ylab="No2 Value",
           col="darkmagenta",
           freq=FALSE
)


boxplot(BHM_no2$Value,
        ylab = "No2")

#It can be seen that there are still outlier which are to be removed
#BHM_no2 <- BHM_no2[BHM_no2$Value <= 200,] 

boxplot(BHM_no2$Value,
        ylab = "No2")


write.csv(BHM_no2,"C:/Users/Shubham/OneDrive/Documents/Disteration_R_code/Dissertation_UK_AirQuality/UK_AirQuality_Dissertation/Data ready for forecasting/BHM_NO2_data_for_forecast.csv")


###########Importing PM10 data###########

bhm_pm10= read.csv("C:/Users/Shubham/OneDrive/Documents/Disteration_R_code/Dissertation_UK_AirQuality/UK_AirQuality_Dissertation/Data prepared for Analysis/final_pm10_bhm_data.csv")

#Remove the unwanted columns
colnames(bhm_pm10)
bhm_pm10= within(bhm_pm10, rm(X))

summary(bhm_pm10)

############PM10 Outlier detection
max(bhm_pm10$Value)
min(bhm_pm10$Value)


bhm_pm10$Value <- as.numeric(bhm_pm10$Value)

Hist= hist(bhm_pm10$Value,
           main="Understanding the PM10 data for Manchester",
           xlab="Sensor readings",
           ylab="PM10 Value",
           col="darkmagenta",
           freq=FALSE
)

boxplot(bhm_pm10$Value,
        ylab = "Pm10")

#find Q1, Q3, and interquartile range for values in column Value
Q1 <- quantile(bhm_pm10$Value, .25)
Q3 <- quantile(bhm_pm10$Value, .75)
IQR <- IQR(bhm_pm10$Value)

#only keep rows in dataframe that have values within 1.5*IQR of Q1 and Q3
no_outliers <- subset(bhm_pm10, bhm_pm10$Value> (Q1 - 1.5*IQR) & bhm_pm10$Value< (Q3 + 1.5*IQR))

#Removing negative values
BHM_pm10 <- no_outliers[no_outliers$Value >= 0, ]

#Understanding data after outlier are removed
Hist= hist(BHM_pm10$Value,
           main="Understanding the Pm10 data for Manchester",
           xlab="Sensor readings",
           ylab="Pm10 Value",
           col="darkmagenta",
           freq=FALSE
)


boxplot(BHM_pm10$Value,
        ylab = "Pm10")

#It can be seen that there are still outlier which are to be removed
BHM_pm10 <- BHM_pm10[BHM_pm10$Value <= 500,] 

boxplot(BHM_pm10$Value,
        ylab = "Pm10")


write.csv(BHM_pm10,"C:/Users/Shubham/OneDrive/Documents/Disteration_R_code/Dissertation_UK_AirQuality/UK_AirQuality_Dissertation/Data ready for forecasting/BHM_PM10_data_for_forecast.csv")
