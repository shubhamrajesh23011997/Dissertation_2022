#MC Data Wrangling and cleaning

#Importing NO2 data
mc_no2= read.csv("C:/Users/Shubham/OneDrive/Documents/Disteration_R_code/Dissertation_UK_AirQuality/UK_AirQuality_Dissertation/Data prepared for Analysis/final_no2_mc_data.csv")

#Remove the unwanted columns
colnames(mc_no2)
mc_no2= within(mc_no2, rm(X))

summary(mc_no2)

#Removing NA vlaues:
mc_no2=mc_no2[rowSums(is.na(mc_no2)) == 0,]

mc_no2_1 <-subset(mc_no2, Value!="No data" & Value!="No Data")
mc_no2_1


library(dplyr)

############NO2 Outlier detection
max(mc_no2_1$Value)
min(mc_no2$Value)


mc_no2_1$Value <- as.numeric(mc_no2_1$Value)

Hist= hist(mc_no2_1$Value,
           main="Understanding the No2 data for Manchester",
           xlab="Sensor readings",
           ylab="No2 Value",
           col="darkmagenta",
           freq=FALSE
)

boxplot(mc_no2_1$Value,
        ylab = "No2")

#find Q1, Q3, and interquartile range for values in column Value
Q1 <- quantile(mc_no2_1$Value, .25)
Q3 <- quantile(mc_no2_1$Value, .75)
IQR <- IQR(mc_no2_1$Value)

#only keep rows in dataframe that have values within 1.5*IQR of Q1 and Q3
no_outliers <- subset(mc_no2_1, mc_no2_1$Value> (Q1 - 1.5*IQR) & mc_no2_1$Value< (Q3 + 1.5*IQR))

#Removing negative values
MC_no2 <- no_outliers[no_outliers$Value >= 0, ]

#Understanding data after outlier are removed
Hist= hist(MC_no2$Value,
           main="Understanding the No2 data for Manchester",
           xlab="Sensor readings",
           ylab="No2 Value",
           col="darkmagenta",
           freq=FALSE
)


boxplot(MC_no2$Value,
        ylab = "No2")

#It can be seen that there are still outlier which are to be removed
#MC_no2 <- MC_no2[MC_no2$Value <= 200,] 

boxplot(MC_no2$Value,
        ylab = "No2")

write.csv(MC_no2,"C:/Users/Shubham/OneDrive/Documents/Disteration_R_code/Dissertation_UK_AirQuality/UK_AirQuality_Dissertation/Data ready for forecasting/MC_NO2_data_for_forecast.csv")


###########Importing PM10 data###########

mc_pm10= read.csv("C:/Users/Shubham/OneDrive/Documents/Disteration_R_code/Dissertation_UK_AirQuality/UK_AirQuality_Dissertation/Data prepared for Analysis/final_pm10_mc_data.csv")

#Remove the unwanted columns
colnames(mc_pm10)
mc_pm10= within(mc_pm10, rm(X))

summary(mc_pm10)

#Removing NA values:
mc_pm10_1 =mc_pm10[!(is.na(mc_pm10$Value) | mc_pm10$Value==""), ]
mc_pm10_1

mc_pm10_2 <-subset(mc_pm10_1, Value!="No data" & Value!="No Data")
mc_pm10_2

summary(mc_pm10_2)



############PM10 Outlier detection
max(mc_pm10_2$Value)
min(mc_pm10_2$Value)


mc_pm10_2$Value <- as.numeric(mc_pm10_2$Value)

Hist= hist(mc_pm10_2$Value,
           main="Understanding the PM10 data for Manchester",
           xlab="Sensor readings",
           ylab="PM10 Value",
           col="darkmagenta",
           freq=FALSE
)

boxplot(mc_pm10_2$Value,
        ylab = "No2")

#find Q1, Q3, and interquartile range for values in column Value
Q1 <- quantile(mc_pm10_2$Value, .25)
Q3 <- quantile(mc_pm10_2$Value, .75)
IQR <- IQR(mc_pm10_2$Value)

#only keep rows in dataframe that have values within 1.5*IQR of Q1 and Q3
no_outliers <- subset(mc_pm10_2, mc_pm10_2$Value> (Q1 - 1.5*IQR) & mc_pm10_2$Value< (Q3 + 1.5*IQR))

#Removing negative values
MC_pm10 <- no_outliers[no_outliers$Value >= 0, ]

#Understanding data after outlier are removed
Hist= hist(MC_pm10$Value,
           main="Understanding the Pm10 data for Manchester",
           xlab="Sensor readings",
           ylab="Pm10 Value",
           col="darkmagenta",
           freq=FALSE
)


boxplot(MC_pm10$Value,
        ylab = "Pm10")

#It can be seen that there are still outlier which are to be removed
#MC_pm10 <- MC_pm10[MC_pm10$Value <= 150,] 

boxplot(MC_pm10$Value,
        ylab = "Pm10")

write.csv(MC_pm10,"C:/Users/Shubham/OneDrive/Documents/Disteration_R_code/Dissertation_UK_AirQuality/UK_AirQuality_Dissertation/Data ready for forecasting/MC_PM10_data_for_forecast.csv")

