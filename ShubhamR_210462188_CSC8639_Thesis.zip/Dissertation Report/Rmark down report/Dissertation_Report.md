---
title: An Empirical Study of Existing and Prospective Air Pollutant level in UK Cities, and its Relationship with Weather
author: "Shubham Rajesh"
date: "23/08/2022"
output: 
  pdf_document:
    keep_md: yes
---




\pagenumbering{arabic}

\begingroup
\centering
# Abstract {-}
\endgroup

**Context** : Over the past few years, air pollution in urban areas has become significantly worse. With expanding industrialisation and the release of more harmful compounds into the air, air pollution is increasing at an alarming rate. Forecasting time series data is challenging, as is identifying the factors that influence it. Understanding the air quality data may aid in forecasting the air quality, also allowing the air quality regulatory bodies to make crucial decisions promptly.

**Objectives** : The purpose of this study is to compare, visualise, and forecast air quality of Birmingham, Manchester, and Newcastle upon Tyne by using publicly available Air quality data. This study includes primarily suspended nitrogen dioxide $NO_2$ and particulate matter $PM_{10}$, in compliance with the Essential Variables of the UK's Department of the Environment (EVs). Additionally, understand the correlation between atmospheric temperature and air quality.

**Method** : Data is mined, wrangled, and visually inspected with the help of Python, R, and PowerBI. In this research, Air quality data for all three cities will be compared from January to December 2021. PowerBI was employed to do the geographic visual analysis. The time series data were used to predict $NO_2$ and $PM_{10}$ concentrations using the FB Prophet model. R and PowerBI were utilised to understand the correlation of atmospheric temperature with $NO_2$ and $PM_{10}$ concentration.

**Results** : Visual and statistical analysis reveals that $NO_2$ and $PM_{10}$ concentrations are greater in Manchester City. While the average $NO_2$ concentration in Birmingham is lower, and the average $PM_{10}$ concentration in Newcastle is the lowest of the three, the presence of numerous outlier values indicates that significant fluctuations have occurred, perhaps owing to external sources. The $NO_2$ and $PM_{10}$ concentration hotspots of all three cities were identified using the geospatial visual assessment. FB Prophet model suggested the presence of trend and seasonality patterns, the model itself forecasted values with non-significant errors, ranging between 10 and 20% of MAPE on average. The Correlation analysis suggest positive correlation between $NO_2$ and Atmospheric temperature.

**Novelty** : The work flow followed in this research, used combination of PowerBI, Time series FB Prophet and Correlation to identify the new insights which can be applied to uncover new evidence and discoveries for additional Air Pollutants variables and for different cities.


\newpage
# Introduction
Air pollution is the major environmental concern to public health in the United Kingdom. The yearly mortality from air pollution caused to humans in the United Kingdom is roughly equivalent to 28,000 and 36,000 fatalities annually ('Air pollution', 2022) [1]. Air pollution can induce and exacerbate health impacts in all people, especially the most vulnerable members of the population. Long-term exposure to air pollution can result in chronic disease such as cardiovascular and respiratory ailments, as well as lung cancer, and a shortened lifespan. Short-term increases in air pollution levels are associated with a variety of adverse health outcomes, including impairment of lung function, asthma exacerbation, increases in respiratory and cardiovascular hospital admissions, and death ('Air pollution', 2022) [1].  The illness burden attributed to air pollution is now believed to be comparable to other significant worldwide health concerns, such as an unhealthy diet and cigarette usage, and air pollution is widely acknowledged as the widespread environmental danger to human health (World Health Organization, 2021) [2].

Common causes of air pollution include household combustion devices, motor vehicles, industrial operations, and forest fires. Particulate matter, carbon monoxide, ozone, nitrogen dioxide, and sulphur dioxide are pollutants that pose a significant threat to public health ('Air pollution WHO', 2022) [3]. In the research by (Curtis et al., 2006), the major focus is kept of two most dangerous pollutants Nitrogen dioxide and Particulate matter 10. Nitrogen dioxides are primarily created by industrial/vehicle combustion and n fertilizers oxidation. When reactive oxygen-containing molecules combine with nitrogen in the atmosphere, nitrogen dioxides can be produced (Curtis et al., 2006) [4]. $NO_2$ might result in a variety of negative effects on human health, the environment, and biological ecosystems, including acid rain, ozone depletion, and global warming. Epidemiological studies indicate that exposure to high levels of $NO_2$ in the air as a pollutant increases the risk of lung cancer by around 5-7%. (ex-smokers and non-smokers) (Shams et al., 2021) [5]. 

According to recent research (World Health Organization, 2021) [2], air pollution (PM and O3) was implicated for 4.9 million fatalities in 2017 in both indoor and outdoor locations. Particulate matter (PM) air pollution is one of the leading causes of mortality globally, with both short- and long-term harmful effects on exposure having been evidenced (Stafoggia et al., 2019) [6]. Particulate Matter 10 ($PM_{10}$) comprises any fine airborne solid or liquid particle having an aerodynamic diameter less than 10 micrometer. PM pollution may be caused by both natural and manmade causes, including the combustion of fossil fuels in the transportation sector (Garcia-Franco, 2020) [7]. 

Particulate matter 10 ($PM_{10}$) has a considerable detrimental influence on human health; thus, predicting particulate matter has become one of the world's top priorities, as it plays a crucial role in the successful management of air pollution. Currently, the application of artificial intelligence technology is expanding rapidly, hence enhancing air quality (Rani Samal et al., 2020) [8].

Rapidly deteriorating air quality and extreme climate changes, such as heatwaves, are harming an increasing number of people throughout the world. Heatwaves have long been recognised as a major source of air pollution, resulting in a variety of adverse health, environmental, and economic effects (Cheval et al., 2009), (Garcia-Herrera et al., 2010) [9] [10]. Ozone ($O_3$), particle matter ($PM$), and nitrogen dioxide ($NO_2$) are air pollutants whose concentrations and effects are known to be impacted by heatwaves. When released into the atmosphere from a range of natural and manmade sources, these pollutants pose a significant hazard to human health (World Health Organization, 2010) [11]. As, the $NO_2$ and $PM_{10}$ had such a large impact on human life, so it became the air pollutants which were targeted in this research.

In past few years, forecasting models for air quality have been progressively enhanced and expanded. So that numerous methodologies and approaches for time series data may be utilised to assist focused control of air pollution and avert severe pollution occurrences (Liu et al., 2021) [12].With the advancement of artificial intelligence and machine learning in past few years, forecasting models based on artificial intelligence are gaining popularity and garnering increasing attention. When dealing with nonlinearities and interacting linkages in air pollution modelling, intelligent predictors can reach higher levels of accuracy in their techniques (Zhang et al., 2012) [13]. The primary advantages of the models are that they can handle nonlinear aspects and solve issues using enormous amounts of data. The application does not need an in-depth comprehension of the dynamic and chemical processes between air pollution levels and other atmospheric factors (Cabaneros et al., 2019) [14].

Many well-established businesses have also done extensive study and created their own prediction algorithms in response to the newly discovered possibilities in time-series forecasting. For instance, Facebook, the most popular social media platform, has just released a new time-series prediction algorithm called FBProphet. In the field of weather forecasting, the model's capacity to accommodate for seasonal shifts and the impact of holidays with unpredictable schedules is its most appealing characteristic (Verma et al., 2021) [15].

This research aims to comprehend the existing air pollution level and utilise the FB Prophet model to predict the prospective $NO_2$ and $PM_{10}$ levels based on the present data. The FBProphet model is selected because to its unique ability to categorize periodic changes and accommodate for the impact of holidays with irregular schedules, which is particularly valuable in the field of meteorology.   This paper gives comprehensive guidance on data processing and model training for air quality time-series data for cities in the United Kingdom (Verma et al., 2021) [15].

The key contributions of this paper are to: 

* Perform a comparative study of the existing air quality in Birmingham, Manchester and Newcastle, identify the fluctuations and finding.

* Conduct an empirical investigation with the objective of identifying seasonality trends more precisely and extending the analysis to forecast air quality.

* Understand the Correlation between atmospheric temperature and air quality.


# Literature Review

## Related work:

Several machine learning algorithms have been presented in recent years for handling air pollution prediction challenges. Important works in the subject will be presented and evaluated in this section. The classification of air quality index and its impact on health were investigated in the research by (Gore & Deshpande, 2017). The authors classified their data using the Decision tree and Naive Bayes J48 methods. The collected findings demonstrated that the accuracy of the decision tree algorithm is 91.9978 %. However, the drawback identified in this study, including the fact that the dataset utilised was inadequate. In addition, decision tree approaches are not expected to perform poorly with continuous variables and might have overfitting difficulties [16].

(Nagendra et al., 2007) review the next study, which evaluates the Air Quality around Bangalore, India's traffic junctions from 1997 to 2005. According to the study, the AQIs for the criteria pollutants $SO_2$, $NO_x$, $RSPM$, and SPM are calculated using the technique recommended by the EPA. The result reveals that air pollution levels at all three crossings (i.e., AQM stations) between 1997 and 2005 may be classed as "excellent" or "moderate" for $SO_2$ and NOx, respectively. The AQI value for RSPM concentration was "good" or "moderate" 94% of the time between 1999 and 2005, "bad" 5% of the time, and "very poor" and "severe" 1% of the time. From 1997 to 2005, 91% of the AQI values for SPM concentrations were classed as "excellent" or "moderate," 7% as "poor" and the remaining 2% as "very poor" or "severe." The annual AQI scores for RSPM and SPM are declining, but the prevalence of "good" and "moderate" levels is increasing [17].

The subject of (Naseem et al., 2018) paper is to predict the future values of air quality parameters. The authors had employed the ARIMA model for the forecasts, as it is one of the most generic classes of models for time series analysis and forecasting. The air pollution data has been evaluated using time series analysis, and the anticipated and observed values have been compared. Using the ARIMA model yielded good and dependable results, as demonstrated by the findings. Mean square error, mean absolute error, and root mean square error have been calculated to evaluate the performance of the model [18].

(Athira.V et al., 2018) presented three deep learning models for predicting future $PM_{10}$ concentration values. Gated Recurrent Unit (GRU), Recurrent Neural Networks (RNN), and Long Short-term Memory are the models examined (LSTM). After studying the variants in RNN model topologies, the most appropriate architecture was selected. The result revealed that the GRU network is more efficient than the other two networks. A trend was also established for $PM_{10}$ concentration. Deep learning can provide accurate air quality forecasts by extracting air quality characteristics without any prior knowledge.[19] 

(Kingsy et al., 2016) suggested research for identifying the air quality index. In their work, the authors implemented the K-means technique; however, the dataset utilised in this study was restricted. When attempting to predict future values, K-means algorithms have additional weaknesses [20]. In a separate study, B.K.Jha and S.Pande analysed the FB Prophet Additive and ARIMA sales models. Using the supermarket furniture information, they determined that the FB Prophet forecast was extremely close to actual data [21].

(Kumar Jha & Pande, 2021) have analysed and visualized urban pollution based on the geographical regions studied. They investigated data collected in Tehran between 2009 and 2013 using Apache Spark. They have discovered that the Naive Bayes approach is more accurate than other machine learning algorithms in classifying unknown air quality classes. However, the technique is not suitable for predicting actual time series [22]. 

(Zhu et al., 2018), discussed the forecasting of air pollutants including ozone, particle matter (PM2.5), and sulphur dioxide. They apply optimization and regularisation techniques to forecast the next day's air pollution levels. The values have been predicted using data from two stations. One station forecasts $O_3$ and $SO_2$ levels, while the other reports $O_3$ and $PM_{2.5}$ levels. They have modelled the data based on similarity and grouped them using liner regression. Root-mean-squared error (RMSE) was the criterion for assessment. The limits of this approach stem from the inability of Linear Regression models to predict or manage unexpected occurrences. In addition, just two stations' data are used in this study, limiting its generalizability [23].

Traditionally, time-series data were projected using typical regressive models like as AR, MA, ARMA, and ARIMA (Samira et al., 2014) [24]. These models are highly prevalent in economic and financial data forecasting. The models were not intended to study nonlinear behaviour between variables, nor did they account for the fact that conditional covariance implies variance change over time when the data display conditional covariance. However, this difficulty might be solved by combining it with the Generalized Autoregressive Conditional Heteroskedasticity (GARCH), although optimising its parameters is extremely challenging (Mohamadi et al., 2019) [25]. 



## About Time series Data Mining

Time series is an interdisciplinary issue of significant practical importance. Because it permits discovering, with a certain margin of error, the future values of a series based on its historical values. Numerous successful applications in several domains, including economics, finance, and hydrology, have been documented in the pertinent literature (Tealab, 2018) [26].
Mining time series data originates from the requirement for individuals to visualise data models in accordance with their skills. People rely on intricate strategies to accomplish these jobs. The primary activities associated with time series include content-based querying, anomaly detection, pattern recognition, prediction, clustering, classification, and segmentation. A huge number of decision-making issues in the natural sciences and social sciences cannot be separated from forecasting. Forecasting is the foundation of decision-making (Zong et al. 2012) [27]. 



## About FB-Prophet model

Fbprophet is an open-source programme developed by the core data science team at Facebook for autonomous forecasting of univariate time series data using an additive model. Fbprophet works best with data that has substantial seasonal impacts and historical data that spans many seasons (minimum of 1 month). This model is resistant to missing data and is able to handle outliers and variations in trends with ease, allowing it to produce accurate predictions. Additionally, the model might incorporate seasonality and the holiday season (Verma et al., 2021) [15].
In addition, this model is simple to apply, and anybody who lacks knowledge in forecasting may use it to produce relevant and reliable forecasts, as it only requires the adjustment of a few simple parameters.
Three models comprise the Fbprophet: trend, seasonality, and holiday. Similar to additive models, Prophet attempts to fit several linear and nonlinear functions of time as components, with time as the regressor.
The modelling equation is as follows:


\hfil ![](modeling_fb_prophet.png){ width=40%, height=40}\hfil

where,

*	g(t): piece-wise linear or logistic growth curve for modelling non-periodic changes (i.e., growth over time)
*	s(t): periodic changes (e.g. weekly/yearly seasonality)
*	h(t): effects of holidays (user provided) with irregular schedules
* et: error term accounts for idiosyncratic changes that is not accommodated by the model

1) Trend.
Over the trending or non-periodic portion of the time series, a piecewise linear curve or a saturation growth model is fitted to describe the trend. In order to make sure the model isn't too vulnerable to outliers or missing data; we do a linear fitting.

2) Seasonality:
Because of the seasonality factor s(t), the model can account for variations that occur on a daily, weekly, monthly, and annual basis. Using the Fourier series, prophet is able to fit the impacts of seasonality and make predictions about such effects in the future. In order to get a rough estimate of seasonality, the formula:

\hfil ![](Seasonality_formula_Fb_prophet.png){ width=40%, height=60}\hfil
                           
where P is the duration of the time series (e.g., P=365.25 for annual data or P=7 for weekly data when time is measured in days). The parameters an...bn must be calculated in light of the value of N. N specifies if high frequency variations may be modelled for fitting seasonal patterns that vary rapidly, or whether it is noise causing over-fitting, in which case this parameter should be set to a lower value.

3) Holiday:
Holidays, such as Diwali, New Year's, and Christmas, generate unanticipated changes in predictions, which can lead to an increase in air pollution owing to the burning of firecrackers. The component h(t) contains these erratic schedules. Thus, prophet enables the inculcation of anomalies using a particular list of past and future occurrences; these days are examined independently, and extra parameters are added to the model to accommodate them.


## About correlation between the Air quality and temperature.
(Jayamurugan et al., 2013) have discovered a number of correlations between temperature and relative humidity and the concentration of pollutants throughout the summer, pre-monsoon, monsoon, and post-monsoon seasons of 2010-2011 [28].
The relevance of surface-based air temperature inversions in increasing air pollution concentrations, particularly in the winter, cannot be overstated. Similar to SBI, air pollution has a tight link with meteorological conditions, such as air temperature, relative humidity, wind speed, and sun radiation (Li et al., 2021) [29].


(Theoharatos et al., 2010) and (McMichael et al., 2003) discovered a substantial association between heatwaves and average hourly concentrations of O3, $NO_2$,  and SO2. Similarly, an increase in urban heat islands (UHIs) and air pollution in London, England can be attributed to a combination of rising air pollution levels and high temperatures [30] [31]. 

Another research evaluated the correlation between temperature and air pollution in Birmingham during heatwaves. Overall, the results reveal a linear association and a positive correlation between temperature and air pollution during heatwaves, with the relationship between temperature and air pollution being more pronounced during heatwaves with high intensity and prolonged duration (Kalisa et al., 2018) [32].


## Accuracy Assessment Metrics
The model's performance is assessed by comparing the forecasted values with the test data. So, error is calculated by differencing the actual value (at) with the forecasted value (ft). Then using these errors terms, we calculate the accuracy of the models (Verma et al., 2021) [15].
The metrics used are explained as follows:


1)	Mean Absolute Error (MAE):
It is the average of the absolute error values. In this, the absolute values are considered so that the positive and negative errors cancel out each other hence losing the error value.
                                                  
\hfil ![](MAE.png){ width=20%, height=50 } \hfil
                                                  
where et is the error term.

2) Mean Absolute Percentage Error (MAPE):
As its name implies, it represents the mean of absolute error values. In addition to MAE, the percentage is determined in order to eliminate ambiguity and standardise the data [9]. For instance, the inaccuracy of 1 is large for ten items but low for one thousand values.

\hfil ![](MAPE.png){ width=30%, height=50 } \hfil
 
where (et) is the error term and (at) is the actual value.


3) Root Mean Square Error (RMSE):
Root mean square error may be determined using the formula.         

\hfil ![](RMSE.png){ width=30%, height=50 } \hfil	


where et is the error term.



# Methodology

### a. Data Collection

For this study, data about air pollutants in Newcastle and Birmingham were obtained from Urban observatory, the largest sensor deployment in the United Kingdom and the source of the most open environmental monitoring data. There are six urban observatories in the United Kingdom, including ones in Newcastle, Sheffield, Bristol, Birmingham, Manchester, and Cranfield [33]. The Newcastle Urban Observatory (UO) is a multimillion-pound investment in ubiquitous urban sensing that delivers one of the most extensive collections of real-time environmental data. This research institution, manned mostly by research software engineers, provides open data to community organisations, local and national governments, and research projects ranging from cyber-security to flood predictions [34]. UK Air Information Resource was consulted for information on Manchester sites. Ricardo Energy & Environment hosts and maintains UK-AIR on behalf of the United Kingdom Department for Environment, Food & Rural Affairs and the Devolved Administrations. The United Kingdom has been separated into non-agglomeration zones and agglomeration zones for the purpose of monitoring and reporting air pollution via UK-AIR. There are fifteen non-agglomeration zones identified, which correspond to the Government Offices for the Regions in England and the Scottish Government, Welsh Government, and Department of the Environment in Northern Ireland.

Study's location:
Newcastle urban observatory collects data from around 137 distinct places in the city, whereas Birmingham urban observatory collects data from just 25 distinct areas in the city. On the UK-AIR website, data was only accessible for four locations in Manchester. All locations are depicted in [figure-1], [figure-3], and [figure-5] below. All of these locations collected data on air pollutants including Nitrogen dioxide $NO_2$, Particulate mater 10 microns or smaller $PM_{10}$, sulfur dioxide $SO_2$, Nitorgen oxide $NO$, Particulate mater 1 microns or smaller $PM_1$, Particulate mater 2.5 microns or smaller $PM_{2.5}$, Particulate mater 4 microns or smaller $PM_4$, Carbon monoxide $CO_3$, and Ozone $O_3$. Since sensors record values every second, the amount of data for Newcastle was enormous. In contrast, sensors in Birmingham gathered data just once every half-hour, whilst sensors in Manchester collected data once every hour.
This study focuses primarily on comparing and projecting $NO_2$ and $PM_{10}$ data. In order to maintain the objectivity of the analysis, hourly data from January 1, 2021 through December 31, 2021 was considered.


### Data Understanding and Data Preparation

The information for Birmingham was acquired manually from the Birmingham Urban Observatory website. The data was downloaded per location and consisted of the following variables: 'index,' 'Timestamp,' 'Value,' 'has beginning,' 'has end,' 'duration,' 'longitude,' 'latitude,' and 'height (m)'. And while the data was downloaded according to location, the timestamp was used as the main key to combine the data.

Whereas the Manchester data was manually downloaded from the UK_AIR webpage. The data was downloaded per location and each file had following variables: 'Date', 'Time', 'Value', 'Status'. Here, the time and date had to concatenated to make single value names timestamp. And as the data was downloaded according to the location, the latitude and longitude values were assumed according to the Location name. E.g., Manchester Piccadilly Station- Latitude: 53.478691 and Longitude: -2.22895. Then all the location files were joined using the timestamp as primary key.

For Newcastle data was manually downloaded from the Newcastle Urban Observatory webpage. The data downloaded had following variables: 'Sensor Name', 'Variable', 'Units', 'Timestamp', 'Value', 'Location (WKT)','Ground Height Above Sea Level', 'Sensor Height Above Ground', 'Broker Name', 'Third Party', 'Sensor Centroid Longitude', 'Sensor Centroid Latitude', 'Raw ID'. Data was standardised by keeping data per hour and removing all other columns.

After completing the data preparation stage, all data sets after this step contained five variables.

Table: Dataset description of Newcastle

| **Variable Name** | **Class** | **Information**                            |
|-------------------|-----------|--------------------------------------------|
| Timestamp         | Character | Time series of the data recorded           |
| Variable          | Numeric   | Air pollutant name                         |
| Value             | Numeric   | Value of the sensor recorded               |
| Latitude          | Numeric   | Latitude location of sensor                |
| Longitude         | Numeric   | Longitude location of sensor               |




### c. Data Cleaning and Exploratory data analysis
The data was then cleansed in RStudio by handling missing values and finding and eliminating outliers. Boxplot and histogram were used to identify outliers, while the Interquartile Rule was utilised to eliminate them. To have a better understanding of data, RStudio was utilised. Using PowerBI, the relation between variables was visualised. When month-by-month comparisons of $PM_{10}$ and $NO_2$ measurements were undertaken for all three cities, crucial insights were discovered.

### d. Geospatial Representation

The data collected from Urban observatory and UK-AIR included sensor location information, therefore Longitude and Latitude values were utilised to depict the values on a map of the United Kingdom. The PowerBI map function was utilised for this purpose. The sites on the map were designated using latitude and longitude, and the average level of air pollution was determined and depicted using bubbles for each place. The bigger the bubble, the greater the average amount of air pollution. In addition, bubble colours were chosen based on the average air pollution level.

### e. Predictive Data analytics: Time Series forecasting
The Fbprophet Python library was installed in order to conduct time series forecasting. For training the FB-Prophet model, the data from January 1, 2021, to November 30, 2021, was used, and the data for the subsequent 30-day period was forecasted (December 1st, 2021 - December 31st, 2021). The estimated values were then cross validated using data from December 1, 2021 to December 31, 2021 that had been cleansed. Which provided RMSE and MAPE values for each day as output. In accordance with the predictions, three graphs are generated for each air pollutant ($NO_2$  and $PM_{10}$). In the first graph, the predicted concentration value is compared to the actual concentration value, and the performance metrics RMSE and MAPE are plotted against the number of days remaining on the Horizon (the range of days in forecasting).

### f. Finding Correlation between Atmospheric Temperature and Air pollutant level:
For determining the relationship between Atmospheric temperature and air pollutant level, the data from the Newcastle Urban observatory is utilised. Temperatures collected by sensors each hour are analysed alongside air pollutant levels recorded per hour. For this research, data spanning six months (1st July 2021 to 31st December 2021) are included, as well as data from a single site. First, the two datasets were combined using timestamp values, and then the correlation was computed and shown using the corr() method. In addition, PowerBI was utilised to comprehend the relationship between the variables in question and the time series. The X axis represents the Time series, while the two Y axes represent Temperature and Air pollutant level, respectively.


 

# Results

All the measures for $NO_2$ and $PM_{10}$ are in micrograms in each cubic metre units.

**a. Geospatial Representation:**

Below are the PowerBI-generated Geospatial Representation of $NO_2$ and $PM_{10}$ concentrations by location in Birmingham, Manchester, and Newcastle for the year 2021. It can be seen that the areas marked by bubbles are the locations where the sensors are based, and red bubble are the locations where the Average levels of $NO_2$ and $PM_{10}$ concentration are high.

$$\\[1in]$$

![Location wise Concentration of $NO2$ in Brimingham for year 2021](fig_1_no2_bhm.png){ width=65%, height=200} 


![Location wise Concentration of $PM10$ in Brimingham for year 2021](fig_2_pm10_bhm.png){ width=65%, height=200}



![Location wise Concentration of $NO2$ in Manchester for year 2021](fig_3_no2_mc.png){ width=65%, height=200}

![Location wise Concentration of $PM10$ in Manchester for year 2021](fig_4_pm10_mc.png){ width=65%, height=200} 


![Location wise Concentration of $NO2$ in Newcastle for year 2021](fig_5_no2_ncl.png){ width=65%, height=200}


![Location wise Concentration of $PM10$ in Newcastle for year 2021](fig_6_pm10_ncl.png){ width=65%, height=200}


\newpage

**b. Comparison of Month wise $NO_2$ levels in the UK cites in the year 2021**


![Month wise Comparison of Average $NO2$ level in the UK cities in the year 2021](fig_7_no2_month_comparison.png){ width=95%, height=250 }


For Manchester, The Highest average of $NO_2$ concentration was recorded among all three cities. A pattern can be seen in the Manchester data, where the $NO_2$ concentration is dropping by every month from January to June 2021 and after that from June to December 2021 gradually increase is visible. For Birmingham, the average $NO_2$ concentration value throughout the year is in between 20 -30, except for months August and September 2021, where the $NO_2$ levels have dropped significantly.  Whereas in Newcastle, the average $NO_2$ concentration value throughout the year is in between 25 -32, except for month August 2021, where the $NO_2$ levels have hiked significantly and dropped again. 


**c. Comparison of Month wise $PM_{10}$ levels in the UK cites in the year 2021**

![Month wise Comparison of Average $PM10$ level in the UK cities in the year 2021](fig_8_pm10_month_comparison.png){ width=95%, height=250 }

For Birmingham, December 2021 had the highest Average of $PM_{10}$ Value whereas the lowest was in February. The Average $PM_{10}$ concentration value appears to be increasing throughout the year in Birmingham. Newcastle had the least average of $PM_{10}$ concentration in year 2021 among all three cities. Whereas, Manchester recorded it highest average $PM_{10}$ concentration value in month of March and April.

\newpage

**d. Predictive Analysis- FB Prophet Model**

The Fbprophet Python library was installed in order to conduct time series forecasting. For training the FB-Prophet model, the data from January 1, 2021, to November 30, 2021, was used, and the data for the subsequent 30-day period was forecasted (December 1st, 2021 - December 31st, 2021). The estimated values were then cross-validated using data from December 1, 2021 to December 31, 2021 that had been cleansed. Which provided RMSE and MAPE values for each day as output. In accordance with the predictions, three graphs are generated for each air pollutant ($NO_2$ and $PM_{10}$). In the first graph, the predicted concentration value is compared to the actual concentration value, and the performance metrics RMSE and MAPE are plotted against the number of days remaining on the Horizon (the range of days in forecasting).

![Prediction plot of $NO_2$ and $PM_{10}$ variables of Birmingham City](fig_9_no2_pm10_forecast_bhm.png){ width=95%, height=250 }

![Prediction plot of $NO_2$ and $PM_{10}$ variables of Manchester City](fig_10_no2_pm10_forecast_mc.png){ width=95%, height=250 }


![Prediction plot of $NO_2$ and $PM_{10}$ variables of Newcastle City](fig_11_no2_pm10_forecast_ncl.png){ width=95%, height=250 }

\newpage

**e. Correlation between temperature and Air pollutant levels**


![Correlation matrix and graph](fig_12_Correlation_matrix.png){ width=95%, height=250 }

![Scatter plot of correlation of Temperature VS $PM_{10}$ and Temperature VS $NO_2$](fig_13_Correlation_Temp_VS_NO2_Pm10.png){ width=95%, height=250 }


In $[Fig-12]$ and $[Fig-13]$, it can be observed from the table that Temperature value and $NO2$ value are significantly positively correlated. Whereas Temperature value and $PM_{10}$ value has a trivial negative correlation between them.

\newpage

**f. Visualizing data in PowerBI, to find correlation between the Temperature VS $NO_2$ & $PM_{10}$**

![Month wise Comparison of Avg. $NO_2$ value VS Avg. Temp value of Newcastle](fig_14_Correlation_of_NO2_Temp.png){ width=95%, height=250 }

According to $[Fig-14]$ Average of $NO2$ Value and total Average of Temperature are positively correlated with each other. Over the period of 6 months, both $NO2$ and temperature are dropping gradually.


![Month wise Comparison of Avg. $PM_{10}$ value VS Avg. Temp value of Newcastle](fig_15_Correlation_of_PM10_Temp.png){ width=95%, height=250 }

 According to $[Fig-15]$ Average Temperature value and Average of $PM10$ value has a no correlation until November 1st,2021 but after that negative correlation can be seen. 
 
\newpage
 
# Discussion

The data from the sensors gets recorded at the Birmingham Urban Observatory on a minute-by-minute basis, and these data may be downloaded for public use and research purposes by directly downloading it from the website. User need to select the theme and time frame, and the data will be downloaded. At Birmingham the sensors record the $NO_2$ and $PM_{10}$ value for 18 locations in the city. At the Newcastle Urban Observatory, the data from the sensors is captured minute-by-minute which can be obtained for public usage and research purposes via one of two methods: either manually or via an API. Using one of these approaches, one may access the data for a specific topic and time period. In Newcastle, the $NO_2$ and $PM_{10}$ values are recorded by 65 sensors. On the other hand, Manchester's Air quality data recorded by UK-AIR, for every 1 hour and allows users to retrieve the data only through a manual process. The $NO_2$ and $PM_{10}$ data is only recorded for 4 locations in the city, as a result the Manchester dataset for analysis is small.
These locations were chosen as the pollutant and timeframe only matched for these cities. All other Air pollutants are not recorded at each station in the city of Birmingham and Manchester, causing this study to be limited to solely $NO_2$ and $PM_{10}$.

At both Newcastle and Birmingham, the monthly and daily averages of $NO_2$ and $PM_{10}$ are uniformly distributed, with no noticeable trend. For Manchester, however, both daily and hourly comparisons reveal a trend. On the 14th to 16th of each month, the average $NO_2$ value is significantly increased, and the hourly average $NO_2$ value is greatest between 6:00 p.m. and 9:00 p.m. Additionally, the average daily $PM_{10}$ concentration in Manchester is highest between the 15th and   17th of every month, and it is uniformly spread throughout the day. It is also possible to conclude that the $NO_2$ and $PM_{10}$ levels in Manchester in 2021 are greater than those in the other two cities. While the average $NO_2$ concentration in Birmingham in 2021 is lower than that of the other cities, the average $PM_{10}$ concentration in Newcastle in 2021 is the lowest of the three.

Geospatial visualisation is used by averaging the Air pollutant's concentration values and creating a colour hue segregation that ranges from low concentration to over the limit concentration of air pollutants to identify which location sensor in the city has recorded the highest and lowest average $NO_2$ and $PM_{10}$ concentration value over the course of 1 year. This information might be used to identify areas with the greatest $NO_2$ and $PM_{10}$ concentrations based on the colour hue representation.


The study involves in predicting the concentration of Air Pollutant's across the cities. In this study,
the predictive analysis was carried out using Time Series Analysis in conjunction with the FB-Prophet model.
It is clear that a trend can be observed when forecasting using historical data. The Performance Metrics
RMSE and MAPE are shown versus the number of days remaining on the horizon. The [Fig-18] and
[Fig-19] in the Appendix displays the performance metric values that were acquired across the horizon days based on the forecasting.

Further extension of study was to find if there is evidence of correlation between Atmospheric temperature and $NO_2$ & Atmospheric temperature and $PM_{10}$ value in Newcastle data.   Correlation matrix, correlation graph, and scatter plot were shown for this purpose. Using PowerBI, even the correlation between variables was investigated. The conclusion of the experiment was determined that $NO_2$ concentrations were positively correlated with atmospheric temperatures. And there is no significant evidence of a correlation between $PM_{10}$ and the temperature of the atmosphere.

There are several external factors that affect the level of air pollutants emitted into the environment. Some of the parameters that may be examined are traffic data, population density in the vicinity, and other weather data. These factors will have influence on the levels of air pollutants. The future scope will involve addressing all of the factors that will help in the future examination of the Air Quality across cities or within cities.


# Future Implications

Future implications of this work would include a better understanding of the influence external elements such as humidity, wind speeds, and air pressure have on air quality. The data for those variables that are available, and further analysis will be conducted to formulate a comparison between the cities. In addition, the predictive analysis would necessitate the application of Neural Network models, which have a reduced error rate when forecasting Air Quality data. The suggested technique performs well in terms of forecast accuracy for low-error time series data. However, performance can be enhanced with FB Prophet's fusion algorithms. Scalability might be an additional difficulty when evaluating a huge dataset. In combination with FB Prophet, transfer learning may be used to increase scalability and manage enormous datasets. High-precision real-time predictions are contingent on the model used for training and validation.

# Conclusion

This research focused on comparative study of existing air quality data for Birmingham, Manchester, and Newcastle. Visual and statistical comparisons of data between January and December 2021 represent that $PM_{10}$ and $NO_2$ concentrations are highest in Manchester City, whereas $PM_{10}$ is lowest in Newcastle upon Tyne, and $NO_2$ is lowest in Birmingham City. Even if the final results suggest that Newcastle upon Tyne has lower $PM_{10}$ values, the appearance of many outlier numbers indicates that there have been considerable swings that may be attributable to external factors. The geographical visual analysis of the concentrations, based on the sensor locations in all three cities, indicates the $NO_2$ and $PM_{10}$ concentration levels are high in the Urban areas of the city. For the time series prediction of concentrations, FB Prophet model suggested the presence of trend and seasonality patterns, the model itself forecasted values with non-significant errors, ranging between 10 and 20% of MAPE on average. The Correlation analysis suggested positive correlation between $NO_2$ and Temperature variable.


\newpage

# References

[1]    Air pollution: applying All Our Health. [Online]. Available from: https://www.gov.uk/government/publications/air-pollution-applying-all-our-health/air-pollution-applying-all-our-health (Accessed 22 August 2022).
 
[2]   World Health Organization (2021) COP26 special report on climate change and health: the health argument for climate action. Geneva: World Health Organization. Available from: https://apps.who.int/iris/bitstream/handle/10665/345334/9789240034433-eng.pdf

[3]   Air pollution. [Online] [online]. Available from: https://www.who.int/health-topics/air-pollution (Accessed 15 May 2022).

[4]    Curtis, L., Rea, W., Smith-Willis, P., Fenyves, E. & Pan, Y. (2006) 'Adverse health effects of outdoor air pollutants', Environment International, 32(6), pp. 815-830. Available from: https://doi.org/10.1016/j.envint.2006.03.012

[5]   Shams, S.R., Jahani, A., Kalantary, S., Moeinaddini, M. & Khorasani, N. (2021) 'Artificial intelligence accuracy assessment in $NO_2$ concentration forecasting of metropolises air', Scientific Reports, 11(1), p. 1805. Available from: https://www.nature.com/articles/s41598-021-81455-6

[6]    Stafoggia, M., Bellander, T., Bucci, S., Davoli, M., de Hoogh, K., de' Donato, F., Gariazzo, C., Lyapustin, A., Michelozzi, P., Renzi, M., Scortichini, M., Shtein, A., Viegi, G., Kloog, I. & Schwartz, J. (2019) 'Estimation of daily PM10 and $PM_{2.5}$ concentrations in Italy, 2013-2015, using a spatiotemporal land-use random-forest model', Environment International, 124pp. 170-179. Available from: https://doi.org/10.1016/j.envint.2019.01.016

[7]    Air quality in Mexico City during the fuel shortage of January 2019 - ScienceDirect. [Online]. Available from: https://doi.org/10.1016/j.atmosenv.2019.117131 (Accessed 1 June 2022).

[8] [Rani Samal, K.K., Sathya Babu, K., Panda, A.K. & Das, S.K. (2020) 'Data Driven Multivariate Air Quality Forecasting using Dynamic Fine Tuning Autoencoder Layer', in 2020 IEEE 17th India Council International Conference (INDICON). [Online]. December 2020 pp. 1-6

[9] Cheval, S., Dumitrescu, A. & Bell, A. (2009) 'The urban heat island of Bucharest during the extreme high temperatures of July 2007', Theoretical and Applied Climatology, 97(3-4), pp. 391-401.

[10] R. Garcia-Herrera, J. Diaz, R.M. Trigo, J. Luterbacher, E.M. Fischer 'A review of the European summer heat wave of 2003' Critical Reviews in Environmental Science and Technology, 40 (4) (2010), pp. 267-306

[11] World Health Organization (ed.) (2010) Who guidelines for indoor air quality: selected pollutants. Copenhagen: WHO.

[12] Liu, H., Yan, G., Duan, Z. & Chen, C. (2021) 'Intelligent modeling strategies for forecasting air quality time series: A review', Applied Soft Computing, 102p. 106957.

[13] Zhang, Y., Bocquet, M., Mallet, V., Seigneur, C. & Baklanov, A. (2012) 'Real-time air quality forecasting, part I: History, techniques, and current status', Atmospheric Environment, 60pp. 632-655.

[14] Cabaneros, S.M., Calautit, J.K. & Hughes, B.R. (2019) 'A review of artificial neural network models for ambient air pollution prediction', Environmental Modelling & Software, 119pp. 285-304.

[15] Verma, P., Reddy, S.V., Ragha, L. & Datta, D. (2021) 'Comparison of Time-Series Forecasting Models', in 2021 International Conference on Intelligent Technologies (CONIT). [Online]. June 2021 pp. 1-7.

[16] Gore, R.W. & Deshpande, D.S. (2017) 'An approach for classification of health risks based on air quality levels', in 2017 1st International Conference on Intelligent Systems and Information Management (ICISIM). [Online]. October 2017 pp. 58-61.

[17] S. M. S. Nagendra, K. Venugopal, and S. L. Jones, "Assessment of air quality near traffic intersections
in Bangalore city using air quality indices," Transportation Research Part D: Transport and Environment,
vol. 12, no. 3, pp. 167-176, May 2007, doi: 10.1016/j.trd.2007.01.005.

[18] Naseem, F., Rashid, A., Izhar, T., Khawar, M.I., Bano, S., Ashraf, A. & Adnan, M.N. (2018) 'An integrated approach to air pollution modeling from climate change perspective using ARIMA forecasting', Journal of Applied Agriculture and Biotechnology, 2(2), pp. 37-44.

[19] V, A., P, G., R, V. & K p, S. (2018) 'DeepAirNet: Applying Recurrent Networks for Air Quality Prediction', Procedia Computer Science, 132pp. 1394-1403.

[20] Kingsy, G.R., Manimegalai, R., Geetha, D.M.S., Rajathi, S., Usha, K. & Raabiathul, B.N. (2016) 'Air pollution analysis using enhanced K-Means clustering algorithm for real time sensor data', in 2016 IEEE Region 10 Conference (TENCON). [Online]. November 2016 pp. 1945-1949.

[21] Kumar Jha, B. & Pande, S. (2021) 'Time Series Forecasting Model for Supermarket Sales using FB-Prophet', in 2021 5th International Conference on Computing Methodologies and Communication (ICCMC). [Online]. April 2021 pp. 547-554.

[22] [M. Asgari, M. Farnaghi, and Z. Ghaemi, ''Predictive mapping of urban air pollution using apache spark on a hadoop cluster,'' in Proc. Int. Conf. Cloud Big Data Comput., 2017, pp. 89-93.

[23] D. Zhu, C. Cai, T. Yang, and X. Zhou, ''A machine learning approach for air quality prediction: Model regularization and optimization,'' Big Data Cogn. Comput., vol. 2, no. 1, p. 5, 2018.

[24] Samira, Muhammad & Salh, & Ahmed, Salah. (2014). Box -Jenkins Models For Forecasting The Daily Degrees Of Temperature In Sulaimani City. International Journal of Engineering Research and Applications (IJERA). 4. 2248-9622.

[25] Salman Mohamadi, Farhang Yeganegi and Nasser M Nasrabadi. Detection and Statistical Modeling of Birth-Death Anomaly, 2019; arXiv:1906.11788.

[26] Tealab, A. (2018) 'Time series forecasting using artificial neural networks methodologies: A systematic review', Future Computing and Informatics Journal, 3(2), pp. 334-340.

[27] J. F. Li and Q. Zong, ''The forecasting of the elevator traffic flow time series based on ARIMA and GP,'' Adv. Mater. Res., vols. 588-589, pp. 1466-1471, Nov. 2012.

[28] Jayamurugan, R., Kumaravel, B., Palanivelraja, S. & Chockalingam, M.P. (2013) 'Influence of Temperature, Relative Humidity and Seasonal Variability on Ambient Air Quality in a Coastal Urban Area', International Journal of Atmospheric Sciences, 2013pp. 1-7.

[29] Li, X.; Miao, Y.; Ma, Y.; Wang, Y.; Zhang, Y. Impacts of synoptic forcing and topography on aerosol pollution during winter in Shenyang, Northeast China. Atmos. Res. 2021, 262, 105764, DOI: https://doi.org/10.1016/j.atmosres.2021.105764

[30] Theoharatos, G., Pantavou, K., Mavrakis, A., Spanou, A., Katavoutas, G., Efstathiou, P., et al. (2010). Heat waves observed in 2007 in Athens, Greece: Synoptic conditions, bioclimatological assessment, air quality levels and health effects. Environmental Research, 110(2), 152-161

[31] McMichael, A. J., Campbell-Lendrum, D. H., Corvalan, C. F., Ebi, K. L., Githeko, A. K., Scheraga, J. D., et al. (2003). Climate change and human health: Risks and responses.
Geneva: World Health Organization

[32] Kalisa, E., Fadlallah, S., Amani, M., Nahayo, L. & Habiyaremye, G. (2018) 'Temperature and air pollution relationship during heatwaves in Birmingham, UK', Sustainable Cities and Society, 43pp. 111-120.

[33]   Bham Urban Obs Data. [online]. Available from: https://data.birminghamurbanobservatory.com/map/platforms (Accessed 8 June 2022).

[34]   Urban Observatory. [Online]. Available from: https://newcastle.urbanobservatory.ac.uk/ (Accessed 8 June 2022).

[35] Siami-Namini, S., Tavakoli, N. & Siami Namin, A. (2018) 'A Comparison of ARIMA and LSTM in Forecasting Time Series', in 2018 17th IEEE International Conference on Machine Learning and Applications (ICMLA). [Online]. December 2018 pp. 1394-1401.

[36] M. Krieger, "Time Series Analysis with Facebook Prophet: How it works and How to use it," Medium,
Mar. 12, 2021. https://towardsdatascience.com/time-series-analysis-with-facebook-prophet-how-it-worksand-
how-to-use-it-f15ecf2c0e3a (accessed Aug. 29, 2021).

[37] "Prophet: forecasting at scale," Facebook Research, Feb. 23, 2017. https://research.fb.com/blog/2017/
02/prophet-forecasting-at-scale/ (accessed Jul. 23, 2022).

[38] "Time Series Forecasts using Facebook's Prophet," Analytics Vidhya, May 10, 2018. https:www.analyticsvidhya.com/blog/2018/05/generate-accurate-forecasts-facebook-prophet-python-r/ (accessed Jul. 29, 2022).


[39] "Prophet," Prophet. http://facebook.github.io/prophet/ (accessed July. 25, 2022).

[40] A. Saxena, J. Celaya, B. Saha, S. Saha, and K. Goebel, "Evaluating algorithm performance metrics tailored for prognostics," in 2009 IEEE Aerospace conference, Mar. 2009, pp. 1-13. doi: 
10.1109/AERO.2009.4839666.

\newpage

# Appendix


## Comparison of Day wise $NO_2$ and $PM_{10}$ levels in the UK cites in the year 2021

![Day wise Comparison of Average $PM10$ level in the UK cities in the year 2021](fig_16_no2_daily_comparison){ width=95%, height=250 }

![Day wise Comparison of Average $PM10$ level in the UK cities in the year 2021](fig_17_pm10_daily_comparison){ width=95%, height=250 }


## Performance matrix produced by FB Prophet model:

![Performance metrics values of Birmingham City](fig_18_bhm_Performace_matrix_forecast.png){ width=95%, height=250 }

![Performance metrics values of Manchester City](fig_19_mc_Performace_matrix_forecast.png){ width=95%, height=250 }

![Performance metrics values of Newcastle upon Tyne City](fig_20_ncl_Performace_matrix_forecast.png){ width=95%, height=250 }
